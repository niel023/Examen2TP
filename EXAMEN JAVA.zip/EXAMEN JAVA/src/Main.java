import java.util.Scanner;
import java.util.Random;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int menu=0;
		int i=0;
		
		int num2=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1-Tarea 1");
		System.out.println("2-Tarea 2");
		System.out.println("3-Tarea 3");
		System.out.println("4-Tarea 4");
		menu=sc.nextInt();
		
		if(menu==1)
		{
			
			
			for (i = 0; i < 10; ++i) {
				System.out.println("Dani");
			}
		
		
					
		}
		if(menu==2)
		{
			while(num2>-1)
			{
				System.out.println("Escribe un numero");
				num2=sc.nextInt();
				
			};
			System.out.println("Has escrito un numero negativo");
			
			
		}
		if (menu==3) 
		{
			Coche[] coche=new Coche[2];
			coche[1]=new Coche("FERRARI", "rojo");
			coche[2]=new Coche("CLIO", "azul");
			Alumno[] alumno=new Alumno[2];
			alumno[1]=new Alumno("Juan", 6.75);
			alumno[2]=new Alumno("Matias", 5.1);
			
			if(alumno[1].getNota()>alumno[2].getNota())
			{
				System.out.println("El alumno "+alumno[1].getNombre()+" ha ganado el "+coche[1].getMarca()+" de color "+coche[1].getColor());
				
				System.out.println("El alumno "+alumno[2].getNombre()+" ha ganado el "+coche[2].getMarca()+" de color "+coche[2].getColor());
			}
			else
			{
				System.out.println("El alumno "+alumno[2].getNombre()+" ha ganado el "+coche[1].getMarca()+" de color "+coche[1].getColor());
				
				System.out.println("El alumno "+alumno[1].getNombre()+" ha ganado el "+coche[2].getMarca()+" de color "+coche[2].getColor());
			}
			
		}
		if(menu==4)
		{
			
		}
			
		
	
		
		
		
		
		
		
		
		

	}
	
	
	public static String fechasalt()
	{
		String fechas="";
		ArrayList<String> fechas = new ArrayList<String>();
		for(int a=0;a<10;a++)
		{
			int numero = (int)(Math.random()*10+1);
			LocalDate fechaActual1 = LocalDate.now();	
			LocalDate fechanueva=fechaActual1.plusMonths(numero).plusDays(numero);
			fechanueva.toString();
		
			fechas.add(); 
		}
		
	}

}
