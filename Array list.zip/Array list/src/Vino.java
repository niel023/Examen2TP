
public class Vino {


    public String nombre;
    public int año;
    public String tipoVino;
    public String bodega;


    public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public Integer getAño() {
		return año;
	}


	public void setAño(int año) {
		this.año = año;
	}


	public String getTipoVino() {
		return tipoVino;
	}


	public void setTipoVino(String tipoVino) {
		this.tipoVino = tipoVino;
	}


	public String getBodega() {
		return bodega;
	}


	public void setBodega(String bodega) {
		this.bodega = bodega;
	}


	public Vino(String Nombre, int Año, String TipoVino, String Bodega)
    {
        this.bodega=Bodega;
        this.nombre=Nombre;
        this.año=Año;
        this.tipoVino=TipoVino;

    }
	
	
	
	public static String añadir() {

		return "a";




    

    
	}

	
}

