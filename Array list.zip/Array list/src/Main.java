import java.util.ArrayList;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		String nombre="";
		String tipo="";
		String bodega="";
		int año=0;
		int selec=0;
		int selec2=0;
		int i=0;
		int a=0;
		int eliminar=0;
		Vino[] vino=new Vino[1000];
		Scanner sc = new Scanner(System.in);
		ArrayList<Vino> Bodega = new ArrayList<Vino>();

		selec=menu(selec);

	
		do	
		{
			do	
			{
				
		
				if(selec==1)
				{
					//Bodega.add(nombre);
					for(i=0;i<a;i++)
					{
						System.out.println("-----------------------------------------------");
						System.out.println();
						System.out.println("El nombre del vino es: "+vino[i].nombre);
						System.out.println("El del año: "+vino[i].año);
						System.out.println("El tipo de vino es: "+vino[i].tipoVino);
						System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
						System.out.println();
						System.out.println("-----------------------------------------------");
						System.out.println();
					}	
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<2)
					{
						break;
					}
					
				}
				if(selec==2)
				{
					do {
						selec2=2;
						System.out.println("Nombre del vino.");
						nombre=sc.next();
						System.out.println("Año del vino.");
						año=sc.nextInt();
						System.out.println("Tipo del vino.");
						tipo=sc.next();
						System.out.println("Bodega del vino.");
						bodega=sc.next();
						System.out.println("Para añadir otro vino pulsa 1. para salir al menÃº pulsa 2");
						selec2=sc.nextInt();
						vino[a]=new Vino(nombre,año,tipo,bodega);
						a++;
					}while(selec2<=1);
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<3)
					{
						break;
					}
					
				}
				if(selec==3)
				{
					System.out.println("-----------------------------------------------------");
					System.out.println("SELECCIONA CON UN NÚMERO EL VINO QUE QUIERES ELIMINAR");
					System.out.println("-----------------------------------------------------");
					for(i=0;i<a;i++)
					{
						System.out.println("-----------------------------------------------");
						System.out.println();
						System.out.println("VINO: "+i);
						System.out.println();
						System.out.println("El nombre del vino es: "+vino[i].nombre);
						System.out.println("El del año: "+vino[i].año);
						System.out.println("El tipo de vino es: "+vino[i].tipoVino);
						System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
						System.out.println();
						System.out.println("-----------------------------------------------");
						System.out.println();
					}
					eliminar=sc.nextInt();

					//Bodega.remove(vino[eliminar].nombre);
					//Bodega.remove(vino[eliminar].año);
					//Bodega.remove(vino[eliminar].tipoVino);
					//Bodega.remove(vino[eliminar].bodega);
					vino[eliminar].nombre=null;
					vino[eliminar].año=0;
					vino[eliminar].tipoVino=null;
					vino[eliminar].bodega=null;

					System.out.println();
					System.out.println();
					System.out.println();


					selec=menu(selec);
					if(selec<4)
					{
						break;
					}
				
					// ELIMINAR UN VALOR DE LA LISTA.
				}
				if(selec==4)
				{

					Bodega.clear();
					
					System.out.println("-----------------------------------------------");
					System.out.println("SE HA BORRADO TODA LA INFORMACIÓN DE LA BODEGA.");
					System.out.println("-----------------------------------------------");
					// ELIMINAR TODOS LOS VALORES DE LA LISTA.
					System.out.println();
					System.out.println();
					System.out.println();
					a=0;

					selec=menu(selec);
					if(selec<5)
					{
						break;
					}
				}
				if(selec==5)
				{
					String nombrebus;
					System.out.println("--------------------------------------------------------");
					System.out.println("ESCRIBE EL NOMBRE DE UN VINO PARA BUSCARLO EN LA BODEGA.");
					System.out.println("--------------------------------------------------------");
					System.out.println();
					nombrebus=sc.nextLine();
					for(i=0;i<a;i++)
					{
						
						//Boolean cont = Bodega.contains(nombrebus);
						if(nombrebus==vino[i].nombre)
						{
							System.out.println("-----------------------------------------------");
							System.out.println();
							System.out.println("VINO: "+i);
							System.out.println();
							System.out.println("El nombre del vino es: "+vino[i].nombre);
							System.out.println("El del año: "+vino[i].año);
							System.out.println("El tipo de vino es: "+vino[i].tipoVino);
							System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
							System.out.println();
							System.out.println("-----------------------------------------------");
						}
										
					}
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<6)
					{
						break;
					}
					

				}
				if(selec==6)
				{
					int añobus;
					System.out.println("--------------------------------------------------------");
					System.out.println("ESCRIBE EL AÑO DE UN VINO PARA BUSCARLO EN LA BODEGA.");
					System.out.println("--------------------------------------------------------");
					System.out.println();
					añobus=sc.nextInt();
					for(i=0;i<a;i++)
					{
						//Boolean cont = Bodega.contains(añobus);
						
						if(vino[i].año==añobus)
						{
							System.out.println("-----------------------------------------------");
							System.out.println();
							System.out.println("VINO: "+i);
							System.out.println();
							System.out.println("El nombre del vino es: "+vino[i].nombre);
							System.out.println("El del año: "+vino[i].año);
							System.out.println("El tipo de vino es: "+vino[i].tipoVino);
							System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
							System.out.println();
							System.out.println("-----------------------------------------------");
						}
					
					}	
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<7)
					{
						break;
					}
					

				}
				if(selec==7)
				{
					String tipobus;
					System.out.println("--------------------------------------------------------");
					System.out.println("ESCRIBE EL TIPO DE UN VINO PARA BUSCARLO EN LA BODEGA.");
					System.out.println("--------------------------------------------------------");
					System.out.println();
					tipobus=sc.nextLine();
					for(i=0;i<a;i++)
					{
						
						//Boolean cont = Bodega.contains(tipobus);
						if(vino[i].tipoVino==tipobus)
						{
							System.out.println("-----------------------------------------------");
							System.out.println();
							System.out.println("VINO: "+i);
							System.out.println();
							System.out.println("El nombre del vino es: "+vino[i].nombre);
							System.out.println("El del año: "+vino[i].año);
							System.out.println("El tipo de vino es: "+vino[i].tipoVino);
							System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
							System.out.println();
							System.out.println("-----------------------------------------------");
						}
					
						
					}	
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<8)
					{
						break;
					}
					

				}
				
				if(selec==8)
				{
					int selecgabus;
					System.out.println("--------------------------------------------------------");
					System.out.println("SELECCIONA UN NÚMERO PARA REEMPLAZARO POR OTRO VINO.");
					System.out.println("--------------------------------------------------------");
					System.out.println();
					for(i=0;i<a;i++)
					{			
						//Boolean cont = Bodega.contains(selecgabus);							
						System.out.println("-----------------------------------------------");
						System.out.println();
						System.out.println("VINO: "+i);
						System.out.println();
						System.out.println("El nombre del vino es: "+vino[i].nombre);
						System.out.println("El del año: "+vino[i].año);
						System.out.println("El tipo de vino es: "+vino[i].tipoVino);
						System.out.println("El vino pertenece a la bodega: "+vino[i].bodega);
						System.out.println();
						System.out.println("-----------------------------------------------");
						System.out.println();			
					}
					selecgabus=sc.nextInt();

					System.out.println();
					System.out.println();
					System.out.println("Nombre del vino.");
					vino[selecgabus].nombre=sc.next();
					System.out.println("Año del vino.");
					vino[selecgabus].año=sc.nextInt();
					System.out.println("Tipo del vino.");
					vino[selecgabus].tipoVino=sc.next();
					System.out.println("Bodega del vino.");
					vino[selecgabus].bodega=sc.next();
					System.out.println();
					System.out.println();
					System.out.println();

					selec=menu(selec);
					if(selec<9)
					{
						break;
					}
				}
				if(selec==9)
				{
					
					break;
					

				}
	
			}while(1<3);

			if(selec==9)
			{
				break;
			}

		}while(1<3);

		
		
	}
	public static int menu (int selec)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("1-Listado de vino.");
		System.out.println("2-Añadir vino.");
		System.out.println("3-Eliminar vino.");
		System.out.println("4-Eliminar todos los vinos.");
		System.out.println("5-Buscar un vino por su nombre.");
		System.out.println("6-Buscar vino por año.");
		System.out.println("7-Buscar vino por tipo de vino.");
		System.out.println("8-Reemplazar un vino por otro.");
		System.out.println("9-Salir del programa.");
		
		selec=sc.nextInt();
		return selec;

	}

	
	

}
