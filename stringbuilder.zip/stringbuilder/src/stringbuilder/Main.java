package stringbuilder;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		StringBuilder cad1 = new StringBuilder("Hola mundo");
		StringBuilder cad2 = new StringBuilder("123");
		StringBuilder cad3 = new StringBuilder(23);
		
		System.out.println("Las dos primeras cadenas unidas son "+cad1.append(cad2));
		
		System.out.println("La longitud de la primera cadena es de "+cad1.length()+" caracteres.");
		
		System.out.println("La capacidad de la segunda cadena es de "+cad2.capacity());
		
		System.out.println("La primera cadena invertida es "+cad1.reverse());
		
		cad1.reverse();
		
		cad2.insert(2, "456");
		System.out.println(cad2);
		
		cad1.deleteCharAt(1);
		System.out.println(cad1);
		
		System.out.println(cad2.toString());
		
		cad1.setLength(26);
		
		System.out.println(cad1.charAt(4));

		cad1.insert(4, ",");
		System.out.println(cad1);
		
		System.out.println(cad1.compareTo(cad2));
		
		
		System.out.println(cad1.replace(0, 3, "-----"));
		
		
		
		
		
		// SEGUNDO EJERCICIO
		
		String palabra; 
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Escribe una frase o una palabra para comprobar si es un palindromo.");
		palabra=sc.nextLine();

		System.out.println(palindromo(palabra));
				
			

	}

	public static String palindromo(String palabra)
	{
		int i = 0;

		StringBuilder palabra1= new StringBuilder(palabra);
		
		StringBuilder palabra2 = new StringBuilder(palabra);
		
		palabra2.reverse();


		i=palabra2.compareTo(palabra1);
		

		if(i==0)
		{
			return "Es un palindromo";
		}
		else
		{
			return "No es un palindromo";
		}


	}



	
	
}
